<?php
return array (
  'app_version' => 'v4.9.2',
  'full_app_version' => 'v4.9.2 - build 4352-gec723a3da',
  'build_version' => '4352',
  'prerelease_version' => '',
  'hash_version' => 'gec723a3da',
  'full_hash' => 'v4.9.2-9-gec723a3da',
  'branch' => 'master',
);